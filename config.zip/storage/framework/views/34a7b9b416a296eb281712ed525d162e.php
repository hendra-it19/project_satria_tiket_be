<?php $__env->startSection('pages'); ?>
    <?php $carbon = app('Carbon\Carbon'); ?>
    <div class="row">

        <div class="col-12 d-flex justify-content-between align-items-center my-5">
            <h3 class="text-primary">Daftar Transaksi</h3>
        </div>


        <div class="col-12 rounded">

            <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-primary">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-warning">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <table class="table" id="table" data-page-length='10'>
                <thead>
                    <th>ID Transaksi</th>
                    <th>Nama Pembeli</th>
                    <th>Email</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total Harga</th>
                    <th>Keberangkatan</th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->transaction_id); ?></td>
                            <td><?php echo e($row->user->nama); ?></td>
                            <td><?php echo e($row->user->email); ?></td>
                            <td><?php echo e($row->harga); ?></td>
                            <td><?php echo e($row->jumlah); ?></td>
                            <td><?php echo e($row->total_harga); ?></td>
                            <td><?php echo e($carbon::parse($row->ticket->keberangkatan)->diffForHumans()); ?></td>
                            <td>
                                <a href="<?php echo e(route('transactions.show', $row->id)); ?>" class="btn btn-sm d-block">
                                    <i class="fas fa-eye text-primary"></i>
                                </a>
                                

                                <?php if($row->status == 'pending' && $carbon::now() < $carbon::parse($row->ticket->keberangkatan)): ?>
                                    <form action="<?php echo e(route('transactions.bayar', $row->id)); ?>" method="post"
                                        class="d-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <button class="btn btn-sm d-block btn-primary"
                                            onclick="return confirm('Yakin ingin konfirmasi pembayaran langsung?')">
                                            Bayar
                                        </button>
                                    </form>
                                <?php elseif($row->status == 'pending' && $carbon::now() >= $carbon::parse($row->ticket->keberangkatan)): ?>
                                    <button class="btn btn-sm d-block btn-danger" disabled>
                                        Bayar
                                    </button>
                                <?php elseif($row->status == 'proses' && $carbon::now() < $carbon::parse($row->ticket->keberangkatan)): ?>
                                    <form action="<?php echo e(route('transactions.claim', $row->id)); ?>" method="post"
                                        class="d-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <button class="btn btn-sm d-block btn-primary"
                                            onclick="return confirm('Yakin ingin melakukan claim tiket?')">
                                            Claim
                                        </button>
                                    </form>
                                <?php elseif($row->status == 'proses' && $carbon::now() >= $carbon::parse($row->ticket->keberangkatan)): ?>
                                    <button class="btn btn-sm d-block btn-danger" disabled>
                                        Claim
                                    </button>
                                <?php elseif($row->status == 'selesai' && $carbon::now() < $carbon::parse($row->ticket->keberangkatan)): ?>
                                    <button class="btn btn-sm d-block btn-outline-primaryy" disabled>
                                        Proses
                                    </button>
                                <?php elseif($row->status == 'selesai' && $carbon::now() >= $carbon::parse($row->ticket->keberangkatan)): ?>
                                    <button class="btn btn-sm d-block btn-outline-primary" disabled>
                                        Berangkat
                                    </button>
                                <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/transactions/index.blade.php ENDPATH**/ ?>