

<?php $__env->startSection('pages'); ?>
    <?php $carbon = app('Carbon\Carbon'); ?>
    <div class="row">

        <div class="col-12 d-flex justify-content-between align-items-center my-5">
            <h3 class="text-primary">Daftar Pengguna</h3>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-outline-primary">Tambah Akun</a>
        </div>


        <div class="col-12 rounded">

            <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-primary">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-warning">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <table class="table" id="table" data-page-length='10'>
                <thead>
                    <th>No</th>
                    <th>Nama Pengguna</th>
                    <th>Email</th>
                    <th>Handphone</th>
                    <th>Alamat</th>
                    <th>Role</th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->nama); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><?php echo e($row->hp); ?></td>
                            <td><?php echo e($row->alamat); ?></td>
                            <td><?php echo e($row->role); ?></td>
                            <td>
                                <a href="<?php echo e(route('users.show', $row->id)); ?>" class="btn btn-sm d-inline">
                                    <i class="fas fa-eye text-primary"></i>
                                </a>
                                <a href="<?php echo e(route('users.edit', $row->id)); ?>" class="btn btn-sm d-inline">
                                    <i class="fas fa-pen text-warning"></i>
                                </a>
                                <?php if($row->id == 1 && $row->role == 'admin'): ?>
                                    <button class="d-inline btn btn-sm" disabled>
                                        <i class="fas fa-trash text-danger"></i>
                                    </button>
                                <?php else: ?>
                                    <form action="<?php echo e(route('users.destroy', $row->id)); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-sm d-inline"
                                            onclick="return confirm('Yakin ingin menghapus data transaksi?')">
                                            <i class="fas fa-trash text-danger"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/users/index.blade.php ENDPATH**/ ?>