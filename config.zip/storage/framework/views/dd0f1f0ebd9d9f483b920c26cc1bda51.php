

<?php $__env->startSection('pages'); ?>
    <div class="container-fluid">
        <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
            <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
                <div class="bg-white rounded shadow-sm p-4 p-sm-5 my-4 mx-3">
                    <div class="d-flex flex-column align-items-center justify-content-center mb-3">
                        <img src="<?php echo e(asset('logo.png')); ?>" alt="logo" width="70px">
                        <h3>
                            <span>Satria</span><span class="text-primary">Tiket</span>
                        </h3>
                    </div>

                    <p>Masukkan email dan password anda !</p>

                    <?php if($message = Session::get('error_login')): ?>
                        <div class="alert py-2 alert-danger my-4">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($message = Session::get('success_register')): ?>
                        <div class="alert py-2 alert-primary my-4">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('loginPost')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="email"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                is-invalid
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="email" placeholder="name@example.com" name="email" value="<?php echo e(old('email')); ?>">
                            <label for="email">Alamat Email</label>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-floating mb-4">
                            <input type="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                is-invalid
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="password" placeholder="Password" name="password">
                            <label for="password">Password</label>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="ingat_saya" name="ingat_saya"
                                    value="1">
                                <label class="form-check-label" for="ingat_saya">Ingat Saya</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary py-2 w-100 mb-4">Masuk</button>
                    </form>
                    <?php if($is_register): ?>
                        <p class="text-center mb-0">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar</a></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/auth/login.blade.php ENDPATH**/ ?>