

<?php $__env->startSection('pages'); ?>
    <div class="row">
        <div class="col-12 my-3">
            <p><a href="<?php echo e(route('ships.index')); ?>">Kapal > </a> Tambah Data</p>
            <h3 class="text-primary">Tambah Daftar Kapal</h3>
        </div>

        <div class="col-12">
            <form action="<?php echo e(route('ships.store')); ?>" method="post" class="row">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>

                <div class="mb-3 col-12 col-md-5">
                    <label for="nama_kapal" class="form-label">Nama Kapal</label>
                    <input type="text" id="nama_kapal" name="nama_kapal"
                        class="form-control <?php $__errorArgs = ['nama_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('nama_kapal')); ?>">
                    <?php $__errorArgs = ['nama_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3 col-12 col-md-5">
                    <label for="kapasitas_penumpang" class="form-label">Kapasitas Penumpang</label>
                    <input type="number" id="kapasitas_penumpang" name="kapasitas_penumpang"
                        class="form-control <?php $__errorArgs = ['kapasitas_penumpang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('kapasitas_penumpang')); ?>">
                    <?php $__errorArgs = ['kapasitas_penumpang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3 col-12 col-md-5">
                    <label for="panjang_kapal" class="form-label">Panjang Kapal (m)</label>
                    <input type="number" id="panjang_kapal" name="panjang_kapal"
                        class="form-control <?php $__errorArgs = ['panjang_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('panjang_kapal')); ?>">
                    <?php $__errorArgs = ['panjang_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3 col-12 col-md-5">
                    <label for="lebar_kapal" class="form-label">Lebar Kapal (m)</label>
                    <input type="number" id="lebar_kapal" name="lebar_kapal"
                        class="form-control <?php $__errorArgs = ['lebar_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('lebar_kapal')); ?>">
                    <?php $__errorArgs = ['lebar_kapal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3 col-12 col-md-5">
                    <label for="tahun_produksi" class="form-label">Tahun Produksi</label>
                    <input type="number" id="tahun_produksi" name="tahun_produksi"
                        class="form-control <?php $__errorArgs = ['tahun_produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('tahun_produksi')); ?>">
                    <?php $__errorArgs = ['tahun_produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div>
                    <button class="btn btn-primary">Simpan</button>
                    <a href="<?php echo e(route('ships.index')); ?>" class="btn btn-outline-danger">Batal</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/ships/create.blade.php ENDPATH**/ ?>