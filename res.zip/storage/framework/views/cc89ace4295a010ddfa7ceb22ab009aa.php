<?php $__env->startSection('pages'); ?>
    <?php $carbon = app('Carbon\Carbon'); ?>
    <?php $number = app('Illuminate\Support\Number'); ?>
    <div class="row">

        <div class="col-12 justify-content-between align-items-center mt-5 mb-3">
            <h3 class="text-primary">Detail Transaksi</h3>
            <p><a href="<?php echo e(route('transactions.index')); ?>">Transaksi</a> / Detail</p>
        </div>


        <div class="col-12 rounded">
            <div class="mb-3">
                <table>
                    <tr>
                        <td>Nama </td>
                        <td>: <?php echo e($transaction->user->title); ?>, <?php echo e($transaction->user->nama); ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>: <?php echo e($transaction->user->email); ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>: <?php echo e($transaction->user->alamat); ?></td>
                    </tr>
                </table>
            </div>
            <h4>Transaksi</h4>
            <table class="table" data-page-length='10'>
                <thead>
                    <th>ID Transaksi</th>
                    <th>Tujuan</th>
                    <th>Waktu Keberangkatan</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total Harga</th>
                </thead>
                <tbody>
                    <tr><td><?php echo e($transaction->transaction_id); ?></td>
                        <td><?php echo e($transaction->ticket->tujuan); ?></td>
                        <td><?php echo e($transaction->ticket->keberangkatan); ?></td>
                        <td><?php echo e($number->currency($transaction->harga, 'IDR','ID')); ?></td>
                        <td><?php echo e($transaction->jumlah); ?></td>
                        <td><?php echo e($number->currency($transaction->total_harga, 'IDR','ID')); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/transactions/show.blade.php ENDPATH**/ ?>