

<?php $__env->startSection('pages'); ?>
    <div class="row">

        <div class="col-12 d-flex justify-content-between align-items-center my-5 ">
            <h3 class="text-primary">Daftar Kapal</h3>
            <a href="<?php echo e(route('ships.create')); ?>" class="btn btn-outline-primary">Tambah Data Kapal</a>
        </div>



        <div class="col-12 rounded">

            <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-primary">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-warning">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <table class="table" id="table" data-page-length='10'>
                <thead>
                    <th>No</th>
                    <th>Nama Kapal</th>
                    <th>Tahun Produksi</th>
                    <th>Kapasitas</th>
                    <th>Lebar </th>
                    <th>Panjang </th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->nama_kapal); ?></td>
                            <td><?php echo e($row->tahun_produksi); ?></td>
                            <td><?php echo e($row->kapasitas_penumpang); ?></td>
                            <td><?php echo e($row->lebar_kapal); ?> meter</td>
                            <td><?php echo e($row->panjang_kapal); ?> meter</td>
                            <td>
                                
                                <a href="<?php echo e(route('ships.edit', $row->id)); ?>" class="btn btn-sm d-inline">
                                    <i class="fas fa-pen text-warning"></i>
                                </a>
                                <form action="<?php echo e(route('ships.destroy', $row->id)); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-sm d-inline"
                                        onclick="return confirm('Yakin ingin menghapus data kapal <?php echo e($row->nama_kapal); ?>?')">
                                        <i class="fas fa-trash text-danger"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/ships/index.blade.php ENDPATH**/ ?>