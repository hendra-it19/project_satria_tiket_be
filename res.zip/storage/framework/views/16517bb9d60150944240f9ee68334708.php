

<?php $__env->startSection('pages'); ?>
    <?php $carbon = app('Carbon\Carbon'); ?>
    <?php
        $start = $carbon::parse($ticket->created_at);
        $end = $carbon::parse($ticket->keberangkatan);
        $check = $carbon::now()->between($start, $end, true);
    ?>

    <div class="row">

        <div class="col-12 my-3">
            <p><a href="<?php echo e(route('tickets.index')); ?>">Tiket > </a> Tambah Data</p>
            <h3 class="text-primary">Detail Tiket dan Transaksi</h3>
        </div>


        <div class="col-12 mb-4">
            <table>
                <tbody>
                    <tr>
                        <td>Nama Kapal</td>
                        <td>: <?php echo e($ticket->ship->nama_kapal); ?></td>
                    </tr>
                    <tr>
                        <td>Jumlah Stok</td>
                        <td>: <?php echo e($ticket->stok); ?></td>
                    </tr>
                    <tr>
                        <td>Sisa Stok</td>
                        <td>: <?php echo e($ticket->sisa_stok); ?></td>
                    </tr>
                    <tr>
                        <td>Harga</td>
                        <td>: Rp. <?php echo e($ticket->harga); ?></td>
                    </tr>
                    <tr>
                        <td>Tujuan</td>
                        <td>: <?php echo e($ticket->tujuan); ?></td>
                    </tr>
                    <tr>
                        <td>Waktu keberangkatan</td>
                        <td>: <?php echo e($carbon::parse($ticket->keberangkatan)->diffForHumans()); ?></td>
                    </tr>

                </tbody>
            </table>
        </div>



        <div class="col-12 rounded">

            <table class="table" id="table" data-page-length='10'>
                <thead>
                    <th>No</th>
                    <th>Nama Pembeli</th>
                    <th>Email</th>
                    <th>Jumlah</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->user->nama); ?></td>
                            <td><?php echo e($row->user->email); ?></td>
                            <td><?php echo e($row->jumlah); ?></td>
                            <td><?php echo e($row->total_harga); ?></td>
                            <td><?php echo e($row->status); ?></td>
                            <td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div>
                <a href="<?php echo e(route('tickets.index')); ?>" class="btn btn-outline-danger">Kembali</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/tickets/show.blade.php ENDPATH**/ ?>