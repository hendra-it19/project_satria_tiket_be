

<?php $__env->startSection('pages'); ?>
    <div class="row">

        <div class="col-12 d-flex justify-content-between align-items-center my-5 ">
            <h3 class="text-primary">Daftar Jadwal</h3>
            <a href="<?php echo e(route('schedules.create')); ?>" class="btn btn-outline-primary">Tambah Jadwal Kapal</a>
        </div>



        <div class="col-12 rounded">

            <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-primary">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-warning">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

            <table class="table" id="table" data-page-length='10'>
                <thead>
                    <th>No</th>
                    <th>Hari Keberangkatan</th>
                    <th>Jam keberangkatan</th>
                    <th>Tujuan</th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->hari_keberangkatan); ?></td>
                            <td><?php echo e($row->jam_keberangkatan); ?></td>
                            <td><?php echo e($row->tujuan); ?></td>
                            <td>
                                
                                <a href="<?php echo e(route('schedules.edit', $row->id)); ?>" class="btn btn-sm d-inline">
                                    <i class="fas fa-pen text-warning"></i>
                                </a>
                                <form action="<?php echo e(route('schedules.destroy', $row->id)); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-sm d-inline"
                                        onclick="return confirm('Yakin ingin menghapus data jadwal kapal?')">
                                        <i class="fas fa-trash text-danger"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/schedules/index.blade.php ENDPATH**/ ?>