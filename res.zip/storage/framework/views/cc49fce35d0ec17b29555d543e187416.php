    <!-- Sidebar Start -->
    <div class="sidebar pe-4 pb-3">
        <nav class="navbar bg-light navbar-light">
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand mx-4 mb-3 text-center">
                <img src="<?php echo e(asset('logo.png')); ?>" alt="logo" width="60px">
                <h4>Satria<span class="text-primary">Tiket</span></h4>
            </a>
            <div class="d-flex align-items-center ms-4 mb-4">
                <hr>
            </div>
            <div class="navbar-nav w-100">

                <a href="<?php echo e(url('/')); ?>" class="nav-item nav-link <?php if($judulHalaman == 'Dashboard'): ?> active <?php endif; ?>">
                    <i class="fa fa-tachometer-alt me-2"></i>
                    Dashboard
                </a>

                <a href="<?php echo e(route('ships.index')); ?>"
                    class="nav-item nav-link <?php if($judulHalaman == 'Kapal'): ?> active <?php endif; ?>"><i
                        class="fa fa-ship me-2"></i>Kapal</a>

                <a href="<?php echo e(route('schedules.index')); ?>"
                    class="nav-item nav-link <?php if($judulHalaman == 'Jadwal'): ?> active <?php endif; ?>"><i
                        class="fas fa-calendar-week me-2"></i>Jadwal</a>

                <a href="<?php echo e(route('tickets.index')); ?>"
                    class="nav-item nav-link <?php if($judulHalaman == 'Tiket'): ?> active <?php endif; ?>"><i
                        class="fas fa-ticket-alt me-2"></i>Tiket</a>

                <a href="<?php echo e(route('transactions.index')); ?>"
                    class="nav-item nav-link <?php if($judulHalaman == 'Transaksi'): ?> active <?php endif; ?>"><i
                        class="fas fa-clipboard me-2"></i>Transaksi</a>

                <a href="<?php echo e(route('users.index')); ?>"
                    class="nav-item nav-link <?php if($judulHalaman == 'Akun'): ?> active <?php endif; ?>"><i
                        class="fa fa-users me-2"></i>Akun</a>

            </div>
        </nav>
    </div>
    <!-- Sidebar End -->
<?php /**PATH D:\Project\indrianihasim - Tiket kapal\project\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>